import React from 'react'
import Todo from './Components/Todo';
function App() {
    return (
        <div>
            <Todo/>
        </div>
    )
}

export default App;
